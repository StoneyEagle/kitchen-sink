<!-- Copyright (c) NoMercy Labs. SPDX-License-Identifier: CC-BY-SA-4.0 -->

# `@foghorn/site-kit`

Foghorn Astro integration: components, scroll-synced audio player, RSS generator, WebVTT emitter, and build-time sync bridge.

## Installation

```bash
npm install @foghorn/site-kit
```

## Usage

See the `blog-journal` template in this package for a complete example, or consult the [Foghorn documentation](https://github.com/NoMercyLabs/foghorn).

## License

MIT
