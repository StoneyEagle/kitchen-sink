<!-- Copyright (c) NoMercy Labs. SPDX-License-Identifier: MIT -->

# Foghorn — Docs template

Starter documentation site. Sidebar navigation + article pages, backed by
Foghorn's block model so every heading and paragraph is individually
addressable, narratable, and stable across edits.

## Run it

```bash
npm install
npm run dev
```

## Add a page

Pages live under `entries/docs/<slug>/entry.md`. Edit with the Foghorn
editor (`foghorn serve` + the desktop editor) or any markdown editor —
the block markers (`<!-- block: ULID -->`) look after themselves.
