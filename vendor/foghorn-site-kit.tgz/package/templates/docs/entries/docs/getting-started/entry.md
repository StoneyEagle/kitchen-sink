---
title: "Getting started"
slug: getting-started
order: 10
category: Basics
authors: [stoney]
tags: [intro]
excerpt: "Your first documentation page."
---

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH8A -->
# Getting started

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH8B -->
Welcome to your new Foghorn docs site. Every page is a markdown file under `entries/docs/`, with block-level ULIDs so edits are content-addressed and narration stays in sync across rewrites.

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH8C -->
## Adding pages

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH8D -->
Use the Foghorn editor's **New entry** button, or create a folder under `entries/docs/<slug>/` with an `entry.md` inside. The page will appear in the sidebar sorted by the `order` field in the frontmatter (lower numbers first).

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH8E -->
## Next

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH8F -->
Run `npm install && npm run dev` to preview the site locally at `http://localhost:4321`.
