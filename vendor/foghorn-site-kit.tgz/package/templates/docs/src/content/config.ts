// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT
import { defineCollection, z } from "astro:content";

// foghorn:start collections
const docs = defineCollection({
  type: "content",
  schema: z.object({
    title: z.string(),
    order: z.number().default(100),
    category: z.string().optional(),
    authors: z.array(z.string()).default([]),
    license: z.string().optional(),
    tags: z.array(z.string()).default([]),
    excerpt: z.string().optional(),
    ttsDefault: z.string().optional(),
  }),
});

export const collections = { docs };
// foghorn:end
