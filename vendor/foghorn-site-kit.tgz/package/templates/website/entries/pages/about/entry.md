---
title: "About"
slug: about
nav: true
navOrder: 10
authors: [stoney]
excerpt: "About this site."
---

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH9D -->
# About

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH9E -->
Tell visitors who you are and what this site is for. Drop your picture in `public/` and link it from Markdown, or use the editor's image upload when it lands.
