---
title: "Home"
slug: home
home: true
nav: true
navOrder: 1
authors: [stoney]
excerpt: "Welcome."
---

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH9A -->
# Welcome

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH9B -->
This is your landing page. Every paragraph is block-addressable, which means the editor can narrate it, highlight it during playback, and keep audio in sync across edits without re-rendering the whole page.

<!-- block: 01HT7XB4G8VFP0K7DQMCAZVH9C -->
Edit this file at `entries/pages/home/entry.md`, or pick it up in the Foghorn editor.
