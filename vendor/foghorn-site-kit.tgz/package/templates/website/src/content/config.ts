// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT
import { defineCollection, z } from "astro:content";

// foghorn:start collections
const pages = defineCollection({
  type: "content",
  schema: z.object({
    title: z.string(),
    // Pages with `home: true` render at `/` instead of `/<slug>` — there
    // should only be one of them.
    home: z.boolean().default(false),
    nav: z.boolean().default(true),
    navOrder: z.number().default(100),
    authors: z.array(z.string()).default([]),
    license: z.string().optional(),
    tags: z.array(z.string()).default([]),
    excerpt: z.string().optional(),
    ttsDefault: z.string().optional(),
  }),
});

export const collections = { pages };
// foghorn:end
