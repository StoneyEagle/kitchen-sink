<!-- Copyright (c) NoMercy Labs. SPDX-License-Identifier: MIT -->

# Foghorn — Website template

Starter template for a small general-purpose site: a landing page plus
any number of loose pages (`/about`, `/contact`, etc.). Every page is
block-addressable and narratable like a journal entry.

## Run it

```bash
npm install
npm run dev
```

## Pages

Pages live under `entries/pages/<slug>/entry.md`. The page with slug
`home` is the landing page. Any other slug becomes `/<slug>`.
