// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

import { Feed } from "feed";
import type { AuthorConfig, FoghornConfig, RouteConfig } from "./foghorn-config.js";

export interface EntryForFeed {
  slug: string;
  title: string;
  date: string | Date;
  excerpt?: string | null;
  authors: string[]; // author ids
  contentHtml?: string;
  audioUrl?: string | null;
  license?: string | null;
}

export function toRss(config: FoghornConfig, route: RouteConfig, entries: EntryForFeed[]): string {
  if (!route.rss) {
    throw new Error(`Route "${route.id}" has no rss configuration`);
  }

  const site = config.site;
  const feedUrl = new URL(route.rss.feed, site.baseUrl).toString();

  // Collect the set of licenses used across entries to build a channel-level copyright.
  const licenseSet = new Set(
    entries.map((e) => e.license ?? config.defaultLicense).filter(Boolean),
  );
  const licenseNotice = licenseSet.size > 0 ? ` — ${Array.from(licenseSet).join(", ")}` : "";
  const year = new Date().getFullYear();
  const copyright = `Copyright © ${year} ${site.title}${licenseNotice}`;

  const feed = new Feed({
    title: `${site.title} — ${route.title}`,
    description: site.description,
    id: feedUrl,
    link: site.baseUrl,
    language: "en",
    feedLinks: { rss: feedUrl },
    copyright,
  });

  for (const entry of entries) {
    const authorsResolved = entry.authors
      .map((id) => config.authors.find((a) => a.id === id))
      .filter((a): a is AuthorConfig => a !== undefined);

    const itemLink = new URL(route.path.replace(":slug", entry.slug), site.baseUrl).toString();

    feed.addItem({
      title: entry.title,
      id: itemLink,
      link: itemLink,
      date: new Date(entry.date),
      description: entry.excerpt ?? "",
      content: entry.contentHtml ?? entry.excerpt ?? "",
      author: authorsResolved.map((a) =>
        a.gitEmail ? { name: a.name, email: a.gitEmail } : { name: a.name },
      ),
      ...(entry.audioUrl
        ? { enclosure: { url: entry.audioUrl, type: "audio/mpeg", length: 0 } }
        : {}),
    });
  }

  return feed.rss2();
}
