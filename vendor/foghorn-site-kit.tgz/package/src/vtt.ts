// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

import type { Manifest, Segment, TextSegment } from "./manifest.js";

export function toVtt(manifest: Manifest): string {
  const header = "WEBVTT\n";
  const cues: string[] = [];
  let cueIndex = 1;

  for (const seg of manifest.segments) {
    // Only emit cues for text / embed segments — pauses are silence and produce no caption.
    if (seg.kind === "pause") continue;

    const start = formatTime(seg.startOffsetMs);
    const end = formatTime(seg.startOffsetMs + seg.durationMs);
    const label =
      seg.kind === "text" ? extractTextLabel(seg) : `[${(seg as { directive: string }).directive}]`;

    cues.push(`${cueIndex}\n${start} --> ${end}\n${label}\n`);
    cueIndex += 1;
  }

  return `${header}\n${cues.join("\n")}`;
}

function formatTime(ms: number): string {
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1000);
  const ms3 = ms % 1000;
  return `${pad(h, 2)}:${pad(m, 2)}:${pad(s, 2)}.${pad(ms3, 3)}`;
}

function pad(n: number, width: number): string {
  return n.toString().padStart(width, "0");
}

function extractTextLabel(seg: TextSegment): string {
  // If wordTimings are available, stitch them; otherwise fall back to a hash-prefixed label.
  if (seg.wordTimings && seg.wordTimings.length > 0) {
    return seg.wordTimings.map((w) => w.word).join(" ");
  }
  return `[${seg.hash.slice(0, 8)}]`;
}

// Simple variant that emits word-level cues (one cue per word) when timings exist.
export function toWordVtt(manifest: Manifest): string {
  const header = "WEBVTT\n";
  const cues: string[] = [];
  let cueIndex = 1;

  for (const seg of manifest.segments) {
    if (seg.kind !== "text" || !seg.wordTimings || seg.wordTimings.length === 0) continue;
    for (const w of seg.wordTimings) {
      const start = formatTime(seg.startOffsetMs + w.startMs);
      const end = formatTime(seg.startOffsetMs + w.endMs);
      cues.push(`${cueIndex}\n${start} --> ${end}\n${w.word}\n`);
      cueIndex += 1;
    }
  }

  return `${header}\n${cues.join("\n")}`;
}

// Re-export Segment type so consumers can import from this module if needed.
export type { Segment };
