// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT
import { z } from "zod";

const wordTimingSchema = z.object({
  word: z.string(),
  startMs: z.number().nonnegative(),
  endMs: z.number().nonnegative(),
});

const textSegmentSchema = z.object({
  kind: z.literal("text"),
  index: z.number().int().nonnegative(),
  blockId: z.string(),
  hash: z.string(),
  url: z.string(),
  durationMs: z.number().nonnegative(),
  startOffsetMs: z.number().nonnegative(),
  voice: z.string(),
  narrator: z.string().optional(),
  wordTimings: z.array(wordTimingSchema).optional(),
});

const pauseSegmentSchema = z.object({
  kind: z.literal("pause"),
  index: z.number().int().nonnegative(),
  durationMs: z.number().nonnegative(),
  startOffsetMs: z.number().nonnegative(),
});

const embedSegmentSchema = z.object({
  kind: z.literal("embed"),
  index: z.number().int().nonnegative(),
  blockId: z.string(),
  directive: z.string(),
  src: z.string(),
  mode: z.string(),
  durationMs: z.number().nonnegative(),
  startOffsetMs: z.number().nonnegative(),
});

export const segmentSchema = z.discriminatedUnion("kind", [
  textSegmentSchema,
  pauseSegmentSchema,
  embedSegmentSchema,
]);

const keyframeSchema = z.object({
  atMs: z.number().nonnegative(),
  offsetPercent: z.number(),
});

const scrollTimingEntrySchema = z.object({
  blockId: z.string(),
  enterAtMs: z.number().nonnegative(),
  exitAtMs: z.number().nonnegative(),
  keyframes: z.array(keyframeSchema),
});

export const manifestSchema = z.object({
  version: z.literal(1),
  entryId: z.string(),
  slug: z.string(),
  totalDurationMs: z.number().nonnegative(),
  generatedAt: z.string(),
  segments: z.array(segmentSchema),
  scrollTiming: z.array(scrollTimingEntrySchema),
});

export type Manifest = z.infer<typeof manifestSchema>;
export type Segment = z.infer<typeof segmentSchema>;
export type TextSegment = z.infer<typeof textSegmentSchema>;
export type PauseSegment = z.infer<typeof pauseSegmentSchema>;
export type EmbedSegment = z.infer<typeof embedSegmentSchema>;
export type ScrollTiming = z.infer<typeof scrollTimingEntrySchema>;
export type ScrollKeyframe = z.infer<typeof keyframeSchema>;

export function readManifest(json: string): Manifest {
  let raw: unknown;
  try {
    raw = JSON.parse(json);
  } catch (err) {
    throw new Error(`Manifest is not valid JSON: ${String(err)}`);
  }
  const result = manifestSchema.safeParse(raw);
  if (!result.success) {
    const messages = result.error.errors
      .map((e) => `  ${e.path.join(".")}: ${e.message}`)
      .join("\n");
    throw new Error(`Manifest failed validation:\n${messages}`);
  }
  return result.data;
}

export function totalDurationOf(m: Manifest): number {
  return m.totalDurationMs;
}

export function segmentAt(m: Manifest, ms: number): Segment | undefined {
  return m.segments.find((s) => ms >= s.startOffsetMs && ms < s.startOffsetMs + s.durationMs);
}

export function segmentForBlock(
  m: Manifest,
  blockId: string,
): TextSegment | EmbedSegment | undefined {
  for (const s of m.segments) {
    if ((s.kind === "text" || s.kind === "embed") && s.blockId === blockId) {
      return s;
    }
  }
  return undefined;
}
