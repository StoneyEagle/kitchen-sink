// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT
import { z } from "zod";

const fontSchema = z.object({
  provider: z.enum(["bunny", "google", "custom"]).default("bunny"),
  family: z.string().default("Inter"),
  weights: z.string().default("400,500,600,700"),
  customCss: z.string().default(""),
});

const codeSchema = z.object({
  darkTheme: z.string().default("one-dark-pro"),
  lightTheme: z.string().default("github-light"),
});

const siteSchema = z.object({
  title: z.string(),
  description: z.string(),
  baseUrl: z.string(),
  theme: z.string(),
  font: fontSchema.optional(),
  code: codeSchema.optional(),
});

const deploymentSchema = z.object({
  target: z.string(),
  config: z.record(z.unknown()),
});

const rssSchema = z.object({
  feed: z.string(),
  guidFrom: z.string(),
});

const routeSchema = z.object({
  id: z.string(),
  title: z.string(),
  path: z.string(),
  contentDir: z.string(),
  layout: z.string(),
  indexLayout: z.string().optional(),
  rss: rssSchema.optional(),
});

const authorSchema = z.object({
  id: z.string(),
  name: z.string(),
  avatar: z.string().optional(),
  gitEmail: z.string().optional(),
  bio: z.string().optional(),
  agent: z.boolean(),
});

const shareSchema = z.object({
  platforms: z.array(z.string()),
  mastodonInstance: z.string().optional(),
  showShareCounts: z.boolean(),
  position: z.enum(["start", "end", "both"]),
});

const ttsProviderEntrySchema = z.object({
  enabled: z.boolean(),
});

const ttsVoiceEntrySchema = z.object({
  provider: z.string(),
  voiceId: z.string(),
  styles: z.array(z.string()),
});

const ttsSchema = z.object({
  default: z.string(),
  providers: z.record(ttsProviderEntrySchema),
  voices: z.record(ttsVoiceEntrySchema),
});

const aiSchema = z.object({
  default: z.string(),
  providers: z.record(z.unknown()),
  agents: z.array(z.unknown()),
});

const updatesSchema = z.object({
  channel: z.enum(["stable", "beta", "nightly"]),
  autoDownload: z.boolean(),
});

// Per-workspace design choices edited from the editor's Site-design settings
// pane. All keys optional because older configs + freshly-scaffolded templates
// may not carry them; the site-kit falls back to the defaults baked into
// foghorn-theme.css when a key is missing.
const designSchema = z
  .object({
    accent: z.string().optional(),
    uiFont: z.string().optional(),
    monoFont: z.string().optional(),
    codeThemeDark: z.string().optional(),
    codeThemeLight: z.string().optional(),
  })
  .passthrough();

export const foghornConfigSchema = z
  .object({
    version: z.literal(1),
    site: siteSchema,
    deployment: deploymentSchema,
    routes: z.array(routeSchema),
    authors: z.array(authorSchema),
    share: shareSchema,
    defaultLicense: z.string(),
    codeLicense: z.string(),
    tts: ttsSchema,
    ai: aiSchema,
    plugins: z.array(z.unknown()),
    updates: updatesSchema,
    design: designSchema.optional(),
  })
  .strict();

export type FoghornConfig = z.infer<typeof foghornConfigSchema>;
export type RouteConfig = z.infer<typeof routeSchema>;
export type AuthorConfig = z.infer<typeof authorSchema>;

export function readConfig(jsonString: string): FoghornConfig {
  let raw: unknown;
  try {
    raw = JSON.parse(jsonString);
  } catch (err) {
    throw new Error(`foghorn.config.json is not valid JSON: ${String(err)}`);
  }
  const result = foghornConfigSchema.safeParse(raw);
  if (!result.success) {
    const messages = result.error.errors
      .map((e) => `  ${e.path.join(".")}: ${e.message}`)
      .join("\n");
    throw new Error(`foghorn.config.json failed validation:\n${messages}`);
  }
  return result.data;
}
