// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

export const VERSION = "0.1.0";

export { foghornConfigSchema, readConfig } from "./foghorn-config.js";
export type { FoghornConfig, RouteConfig, AuthorConfig } from "./foghorn-config.js";

export { speechDocumentSchema, speechItemSchema, readSpeech } from "./speech.js";
export type { SpeechDocument, SpeechItem } from "./speech.js";

export {
  manifestSchema,
  segmentSchema,
  readManifest,
  totalDurationOf,
  segmentAt,
  segmentForBlock,
} from "./manifest.js";
export type {
  Manifest,
  Segment,
  TextSegment,
  PauseSegment,
  EmbedSegment,
  ScrollTiming,
} from "./manifest.js";

export { toVtt, toWordVtt } from "./vtt.js";

export { toRss } from "./rss.js";
export type { EntryForFeed } from "./rss.js";

// Note: FoghornPlayer (Web Component, extends HTMLElement) is NOT re-exported from the
// main barrel — it would crash in Node-side SSR where HTMLElement is undefined.
// Import it as a side-effect via `@foghorn/site-kit/player` in client-only code
// (see Player.astro's <script> block).
export type { SegmentChangeEvent, TimeUpdateEvent } from "./player/foghorn-player.js";

export { createScrollSync } from "./player/scroll-sync.js";
export type { ScrollSyncDriver, ScrollKeyframe } from "./player/scroll-sync.js";

export { default as foghorn } from "./integrations/foghorn.js";
export type { FoghornIntegrationOptions } from "./integrations/foghorn.js";

export { highlightCode } from "./highlight.js";
export type { HighlightOptions } from "./highlight.js";

export {
  readPrefs,
  writePrefs,
  applyPrefs,
  ensureFontStylesheet,
  FONT_STYLESHEETS,
  BOOT_SCRIPT as READER_PREFS_BOOT,
} from "./reader/reader-prefs.js";
export type {
  ReaderPrefs,
  Scheme,
  FontSize,
  ReaderFont,
} from "./reader/reader-prefs.js";
