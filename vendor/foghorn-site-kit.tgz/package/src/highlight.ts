// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

/**
 * Server-side code highlighter for Astro layouts.
 *
 * Emits dual-theme HTML (defaultColor: false) so the reader's
 * prefers-color-scheme decides which theme's colours actually render.
 * The matching media-query CSS is included by <FoghornHead>.
 */

import { type Highlighter, createHighlighter } from "shiki";

let _promise: Promise<Highlighter> | null = null;

const DEFAULT_DARK = "one-dark-pro";
const DEFAULT_LIGHT = "github-light";

const COMMON_LANGS = [
  "typescript",
  "javascript",
  "tsx",
  "jsx",
  "csharp",
  "python",
  "rust",
  "go",
  "bash",
  "shell",
  "json",
  "yaml",
  "toml",
  "markdown",
  "html",
  "css",
  "vue",
  "sql",
  "dockerfile",
];

async function getHighlighter(
  extraThemes: readonly string[],
): Promise<Highlighter> {
  if (_promise === null) {
    const themes = Array.from(new Set([DEFAULT_DARK, DEFAULT_LIGHT, ...extraThemes]));
    _promise = createHighlighter({
      themes: themes as Parameters<typeof createHighlighter>[0]["themes"],
      langs: COMMON_LANGS as Parameters<typeof createHighlighter>[0]["langs"],
    });
  }
  return _promise;
}

function normaliseLang(raw: string): string {
  const lang = raw.trim().toLowerCase();
  if (lang === "") return "text";
  if (lang === "ts") return "typescript";
  if (lang === "js") return "javascript";
  if (lang === "cs" || lang === "c#") return "csharp";
  if (lang === "py") return "python";
  if (lang === "rs") return "rust";
  if (lang === "sh") return "bash";
  if (lang === "yml") return "yaml";
  if (lang === "md") return "markdown";
  return lang;
}

export interface HighlightOptions {
  darkTheme?: string;
  lightTheme?: string;
}

/**
 * Highlight code to dual-theme HTML. The returned markup has inline
 * colour styles for no theme (defaultColor:false) and CSS variables
 * for both — FoghornHead's media-query CSS picks which to render.
 */
export async function highlightCode(
  code: string,
  lang: string,
  options: HighlightOptions = {},
): Promise<string> {
  const darkTheme = options.darkTheme ?? DEFAULT_DARK;
  const lightTheme = options.lightTheme ?? DEFAULT_LIGHT;
  const hl = await getHighlighter([darkTheme, lightTheme]);
  const l = normaliseLang(lang);
  const langToUse = hl.getLoadedLanguages().includes(l as never) ? l : "text";

  return hl.codeToHtml(code, {
    lang: langToUse,
    themes: { dark: darkTheme, light: lightTheme },
    defaultColor: false,
  });
}
