// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

/**
 * Reader preferences, persisted per-device on the published site.
 * Hydrates as early as possible (inline <script> in <head>) so the
 * chosen scheme / size / font is already on the <html> root before
 * first paint — no flash of default theme.
 *
 * Three knobs:
 *   - scheme:  "auto" | "dark" | "light"
 *   - size:    "sm" | "md" | "lg"
 *   - font:    "default" | "atkinson" | "lexend" | "system"
 */

export type Scheme = "auto" | "dark" | "light";
export type FontSize = "sm" | "md" | "lg";
export type ReaderFont = "default" | "atkinson" | "lexend" | "system";

export interface ReaderPrefs {
  scheme: Scheme;
  size: FontSize;
  font: ReaderFont;
}

export const LS_KEY = "foghorn:reader:v1";

const DEFAULTS: ReaderPrefs = {
  scheme: "auto",
  size: "md",
  font: "default",
};

/** Fonts that require an external stylesheet on pick. */
export const FONT_STYLESHEETS: Readonly<Record<ReaderFont, string | null>> = {
  default: null,
  atkinson: "https://fonts.bunny.net/css?family=atkinson-hyperlegible:400,700&display=swap",
  lexend: "https://fonts.bunny.net/css?family=lexend:400,500,600,700&display=swap",
  system: null,
};

export function readPrefs(): ReaderPrefs {
  if (typeof localStorage === "undefined") return DEFAULTS;
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw === null) return DEFAULTS;
    const parsed = JSON.parse(raw) as Partial<ReaderPrefs>;
    return { ...DEFAULTS, ...parsed };
  } catch {
    return DEFAULTS;
  }
}

export function writePrefs(prefs: ReaderPrefs): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(prefs));
  } catch {
    // Quota / privacy-mode failures are silent — prefs still work in-page.
  }
}

/** Inject the stylesheet for a chosen font if it needs one (idempotent). */
export function ensureFontStylesheet(font: ReaderFont): void {
  if (typeof document === "undefined") return;
  const url = FONT_STYLESHEETS[font];
  if (url === null) return;
  const id = `fg-reader-font-${font}`;
  if (document.getElementById(id) !== null) return;
  const link = document.createElement("link");
  link.id = id;
  link.rel = "stylesheet";
  link.href = url;
  document.head.appendChild(link);
}

export function applyPrefs(prefs: ReaderPrefs): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.dataset["scheme"] = prefs.scheme;
  root.dataset["size"] = prefs.size;
  root.dataset["font"] = prefs.font;
  ensureFontStylesheet(prefs.font);
}

/** Inline snippet included in <head> to apply prefs pre-paint. */
export const BOOT_SCRIPT = `
(function() {
  try {
    var s = localStorage.getItem('${LS_KEY}');
    var p = s ? JSON.parse(s) : {};
    var r = document.documentElement;
    r.dataset.scheme = p.scheme || 'auto';
    r.dataset.size = p.size || 'md';
    r.dataset.font = p.font || 'default';
    var FS = {
      atkinson: 'https://fonts.bunny.net/css?family=atkinson-hyperlegible:400,700&display=swap',
      lexend:   'https://fonts.bunny.net/css?family=lexend:400,500,600,700&display=swap'
    };
    var url = FS[p.font];
    if (url) {
      var id = 'fg-reader-font-' + p.font;
      if (!document.getElementById(id)) {
        var l = document.createElement('link');
        l.id = id; l.rel = 'stylesheet'; l.href = url;
        document.head.appendChild(l);
      }
    }
  } catch (e) {}
})();
`.trim();
