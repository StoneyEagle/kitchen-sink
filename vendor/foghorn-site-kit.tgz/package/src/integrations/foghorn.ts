// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

export interface FoghornIntegrationOptions {
  /** Path to the user's repo root (where foghorn.config.json lives). Defaults to Astro's root. */
  cwd?: string;
  /** Whether to re-run sync.mjs on dev-server config changes. Default true. */
  watchConfig?: boolean;
}

// Using `unknown` here because importing astro's type in a peer-dep context creates circular
// typechecking pain. The shape is structurally compatible with `AstroIntegration`.
export default function foghorn(options: FoghornIntegrationOptions = {}): unknown {
  const syncScript = fileURLToPath(new URL("../sync.mjs", import.meta.url));

  return {
    name: "@foghorn/site-kit",
    hooks: {
      "astro:config:setup": ({
        addWatchFile,
        config,
      }: {
        addWatchFile: (p: string) => void;
        config: { root: URL };
      }) => {
        const cwd = options.cwd ?? fileURLToPath(config.root);
        if (options.watchConfig !== false) {
          addWatchFile(resolve(cwd, "foghorn.config.json"));
        }
        // Initial sync on setup.
        runSync(syncScript, cwd);
      },
      "astro:server:setup": ({
        server,
      }: {
        server: {
          watcher: {
            on: (event: string, cb: (path: string) => void) => void;
          };
        };
      }) => {
        // Re-run sync on config or entry changes during `astro dev`.
        server.watcher.on("change", (path: string) => {
          if (path.endsWith("foghorn.config.json") || path.includes("/entries/")) {
            runSync(syncScript, options.cwd ?? process.cwd());
          }
        });
      },
    },
  };
}

function runSync(syncScript: string, cwd: string): void {
  const r = spawnSync(process.execPath, [syncScript], {
    env: { ...process.env, FOGHORN_CWD: cwd },
    stdio: "inherit",
  });
  if (r.status !== 0) {
    process.stderr.write(`[foghorn] sync failed with exit ${r.status}\n`);
  }
}
