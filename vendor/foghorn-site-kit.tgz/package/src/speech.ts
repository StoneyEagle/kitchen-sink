// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT
import { z } from "zod";

const textItem = z.object({
  kind: z.literal("text"),
  blockId: z.string(),
  narrator: z.string().nullish(),
  text: z.string(),
});

const pauseItem = z.object({
  kind: z.literal("pause"),
  ms: z.number().int().nonnegative(),
  anchor: z
    .object({
      blockId: z.string(),
      side: z.enum(["Leading", "Trailing"]),
    })
    .nullish(),
});

const voiceItem = z.object({
  kind: z.literal("voice"),
  blockId: z.string(),
  voiceId: z.string(),
});

export const speechItemSchema = z.discriminatedUnion("kind", [textItem, pauseItem, voiceItem]);

export const speechDocumentSchema = z.object({
  entryId: z.string(),
  items: z.array(speechItemSchema),
});

export type SpeechDocument = z.infer<typeof speechDocumentSchema>;
export type SpeechItem = z.infer<typeof speechItemSchema>;

export function readSpeech(json: string): SpeechDocument {
  let raw: unknown;
  try {
    raw = JSON.parse(json);
  } catch (err) {
    throw new Error(`Speech sidecar is not valid JSON: ${String(err)}`);
  }
  const result = speechDocumentSchema.safeParse(raw);
  if (!result.success) {
    const messages = result.error.errors
      .map((e) => `  ${e.path.join(".")}: ${e.message}`)
      .join("\n");
    throw new Error(`Speech sidecar failed validation:\n${messages}`);
  }
  return result.data;
}
