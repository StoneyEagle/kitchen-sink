// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

import { type Manifest, readManifest } from "../manifest.js";
import { type ScrollSyncDriver, createScrollSync } from "./scroll-sync.js";

export type SegmentChangeEvent = CustomEvent<{ index: number; blockId: string | undefined }>;
export type TimeUpdateEvent = CustomEvent<{ positionMs: number; totalMs: number }>;

export class FoghornPlayer extends HTMLElement {
  static readonly TAG = "foghorn-player";
  static register(): void {
    if (!customElements.get(FoghornPlayer.TAG)) {
      customElements.define(FoghornPlayer.TAG, FoghornPlayer);
    }
  }

  private audio: HTMLAudioElement = new Audio();
  private manifest: Manifest | null = null;
  private currentIndex = 0;
  private scrollSync: ScrollSyncDriver | null = null;

  connectedCallback(): void {
    this.render();
    this.loadManifestFromAttribute();
    this.audio.addEventListener("ended", this.onEnded);
    this.audio.addEventListener("timeupdate", this.onTimeUpdate);
  }

  disconnectedCallback(): void {
    this.audio.removeEventListener("ended", this.onEnded);
    this.audio.removeEventListener("timeupdate", this.onTimeUpdate);
    this.audio.pause();
    this.scrollSync?.dispose();
  }

  get totalDurationMs(): number {
    return this.manifest?.totalDurationMs ?? 0;
  }

  get positionMs(): number {
    if (!this.manifest) return 0;
    const done = this.manifest.segments
      .slice(0, this.currentIndex)
      .reduce((sum, s) => sum + s.durationMs, 0);
    return done + Math.round(this.audio.currentTime * 1000);
  }

  async loadManifest(source: string | Manifest): Promise<void> {
    let m: Manifest;
    if (typeof source === "string") {
      if (source.trim().startsWith("{")) {
        m = readManifest(source);
      } else {
        const res = await fetch(source);
        m = readManifest(await res.text());
      }
    } else {
      m = source;
    }
    this.manifest = m;
    this.currentIndex = 0;
    this.loadSegment(0);
    this.scrollSync?.dispose();
    if (!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      this.scrollSync = createScrollSync(m);
    }
  }

  play(): Promise<void> {
    return this.audio.play();
  }

  pause(): void {
    this.audio.pause();
  }

  seekToBlock(blockId: string): void {
    if (!this.manifest) return;
    const idx = this.manifest.segments.findIndex(
      (s) => (s.kind === "text" || s.kind === "embed") && s.blockId === blockId,
    );
    if (idx >= 0) {
      this.currentIndex = idx;
      this.loadSegment(idx);
    }
  }

  private loadSegment(index: number): void {
    if (!this.manifest) return;
    const seg = this.manifest.segments[index];
    if (!seg) return;
    this.currentIndex = index;
    if (seg.kind === "pause") {
      // No audio; advance after the pause duration.
      this.audio.src = "";
      window.setTimeout(() => this.advance(), seg.durationMs);
      this.fireSegmentChange(index, undefined);
      return;
    }
    this.audio.src = seg.kind === "text" ? seg.url : seg.src;
    this.fireSegmentChange(index, seg.blockId);
  }

  private advance = (): void => {
    if (!this.manifest) return;
    const next = this.currentIndex + 1;
    if (next < this.manifest.segments.length) {
      this.loadSegment(next);
      this.audio.play().catch(() => {
        /* autoplay policy may block; caller retries */
      });
    } else {
      this.dispatchEvent(new CustomEvent("foghorn:complete"));
    }
  };

  private onEnded = (): void => {
    this.advance();
  };

  private onTimeUpdate = (): void => {
    this.dispatchEvent(
      new CustomEvent<TimeUpdateEvent["detail"]>("foghorn:timeupdate", {
        detail: { positionMs: this.positionMs, totalMs: this.totalDurationMs },
      }),
    );
    this.scrollSync?.onTimeUpdate(this.positionMs);
  };

  private fireSegmentChange(index: number, blockId: string | undefined): void {
    this.dispatchEvent(
      new CustomEvent<SegmentChangeEvent["detail"]>("foghorn:segmentchange", {
        detail: { index, blockId },
      }),
    );
  }

  private render(): void {
    // Guard: happy-dom or some environments may not support attachShadow.
    if (!this.attachShadow) return;
    const shadow = this.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host { display: inline-block; font-family: inherit; }
        button { font: inherit; padding: .5em 1em; cursor: pointer; }
      </style>
      <div part="controls">
        <button type="button" data-action="play" aria-label="Play">▶</button>
        <button type="button" data-action="pause" aria-label="Pause">⏸</button>
      </div>
    `;
    shadow.querySelector('[data-action="play"]')?.addEventListener("click", () => this.play());
    shadow.querySelector('[data-action="pause"]')?.addEventListener("click", () => this.pause());
  }

  private loadManifestFromAttribute(): void {
    const src = this.getAttribute("manifest");
    if (!src) return;
    void this.loadManifest(src);
  }
}

FoghornPlayer.register();
