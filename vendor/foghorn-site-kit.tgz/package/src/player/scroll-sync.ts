// Copyright (c) NoMercy Labs.
// SPDX-License-Identifier: MIT

import type { Manifest, ScrollKeyframe, ScrollTiming } from "../manifest.js";

export interface ScrollSyncDriver {
  onTimeUpdate(positionMs: number): void;
  dispose(): void;
}

interface ScrollTarget {
  scrollHeight?: number;
  clientHeight?: number;
  scrollTo?: (opts: ScrollToOptions) => void;
}

export function createScrollSync(
  manifest: Manifest,
  scroller: ScrollTarget = document.scrollingElement ?? document.documentElement,
): ScrollSyncDriver {
  const timings = manifest.scrollTiming ?? [];
  if (timings.length === 0 || !scroller) {
    return { onTimeUpdate: () => {}, dispose: () => {} };
  }

  let disposed = false;
  return {
    onTimeUpdate(positionMs) {
      if (disposed) return;
      const active = timings.find((t) => positionMs >= t.enterAtMs && positionMs <= t.exitAtMs);
      if (!active) return;
      const target = interpolate(active, positionMs);
      const maxScroll = (scroller.scrollHeight ?? 0) - (scroller.clientHeight ?? 0);
      scroller.scrollTo?.({ top: (target / 100) * maxScroll, behavior: "auto" });
    },
    dispose() {
      disposed = true;
    },
  };
}

function interpolate(timing: ScrollTiming, positionMs: number): number {
  const kfs = timing.keyframes;
  if (kfs.length === 0) return 0;

  const first = kfs[0];
  const last = kfs[kfs.length - 1];
  if (!first || !last) return 0;

  if (positionMs <= first.atMs) return first.offsetPercent;
  if (positionMs >= last.atMs) return last.offsetPercent;

  for (let i = 0; i < kfs.length - 1; i++) {
    const a = kfs[i];
    const b = kfs[i + 1];
    if (!a || !b) continue;
    if (positionMs >= a.atMs && positionMs <= b.atMs) {
      const t = (positionMs - a.atMs) / (b.atMs - a.atMs);
      return a.offsetPercent + t * (b.offsetPercent - a.offsetPercent);
    }
  }

  return last.offsetPercent;
}

export type { ScrollKeyframe };
